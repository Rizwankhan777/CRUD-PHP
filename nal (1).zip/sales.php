<!DOCTYPE html>
<html lang="en">
    <head>
        <title>NAL - Index</title>
        <?php include('inc/styles.php'); ?>
        <body>

        <?php include('inc/header.php'); ?> 
        <?php include('inc/nav.php'); ?> 

            <div class="wrapper">
                <div class="sa4d25">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="section3126">
                                    <div class="row">
                                        <div class="col-xl-3 col-lg-12 col-md-3">
                                            <div class="value_props">
                                                <div class="value_icon">
                                                    <i class='uil uil-history'></i>
                                                </div>
                                                <div class="value_content">
                                                    <h4>Orders</h4>
                                                    <p>6000+</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-3 col-lg-12 col-md-3">
                                            <div class="value_props">
                                                <div class="value_icon">
                                                    <i class='uil uil-user-check'></i>
                                                </div>
                                                <div class="value_content">
                                                    <h4>Customers</h4>
                                                    <p>1500+</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-3 col-lg-12 col-md-3">
                                            <div class="value_props">
                                                <div class="value_icon">
                                                    <i class='uil uil-play-circle'></i>
                                                </div>
                                                <div class="value_content">
                                                    <h4>Parcels</h4>
                                                    <p>50000+</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-3 col-lg-12 col-md-3">
                                            <div class="value_props">
                                                <div class="value_icon">
                                                    <i class='uil uil-presentation-play'></i>
                                                </div>
                                                <div class="value_content">
                                                    <h4>Sales</h4>
                                                    <p>$ 10200.00</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                        </div>
                    </div>
                    
                    <div class="container-fluid">
                        <div class="row">
                            <div id="piechart"></div>
                        </div>
                    </div>

                    
                    
                </div>
                <?php include('inc/footer.php'); ?>
            </div>
            <?php include('inc/scripts.php'); ?>
            <script>
                $(document).ready(function () { $('#example').DataTable(); });
            </script>
            
            <script type="text/javascript">
            // Load google charts
            google.charts.load('current', {'packages':['corechart']});
            google.charts.setOnLoadCallback(drawChart);
            
            // Draw the chart and set the chart values
            function drawChart() {
              var data = google.visualization.arrayToDataTable([
              ['Task', 'Hours per Day'],
              ['Work', 8],
              ['Eat', 2],
              ['TV', 4],
              ['Gym', 2],
              ['Sleep', 8]
            ]);
            
              // Optional; add a title and set the width and height of the chart
              var options = {'title':'My Average Day', 'width':550, 'height':400};
            
              // Display the chart inside the <div> element with id="piechart"
              var chart = new google.visualization.PieChart(document.getElementById('piechart'));
              chart.draw(data, options);
            }
            </script>
            
        </body>
    </html>