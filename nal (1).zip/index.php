<!DOCTYPE html>
<html lang="en">
    <head>
        <title>NAL - Index</title>
        <?php include('inc/styles.php'); ?>
        <body>

        <?php include('inc/header.php'); ?> 
        <?php include('inc/nav.php'); ?> 

            <div class="wrapper">
                <div class="sa4d25">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-xl-9 col-lg-8">
                                <div class="section3125">
                                    <h4 class="item_title">New Orders</h4>
                                    <a href="#" class="see150">See all</a>
                                    <div class="la5lo1">
                                        <div class="owl-carousel featured_courses owl-theme">
                                            <div class="item">
                                                <div class="fcrse_1 mb-20">
                                                    <div class="fcrse_content">
                                                        <div class="eps_dots more_dropdown">
                                                            <a href="#">
                                                                <i class='uil uil-ellipsis-v'></i>
                                                            </a>
                                                            <div class="dropdown-content">
                                                                <span>
                                                                    <i class='uil uil-share-alt'></i>View</span>
                                                                <span>
                                                                    <i class="uil uil-heart"></i>Change Status</span>
                                                                <span>
                                                                    <i class='uil uil-ban'></i>Edit</span>
                                                                <span>
                                                                    <i class="uil uil-windsock"></i>Spam</span>
                                                            </div>
                                                        </div>
                                                        <div class="vdtodt">
                                                            <span class="vdt14">Booking Date: 10/Aug/2022</span>
                                                        </div>
                                                        <a href="javascript:;" class="crse14s">Consignee Name : James Albert</a>
                                                        <a href="#" class="crse-cate">From: Alaska | To: Chicago</a>
                                                        <div class="auth1lnkprce">
                                                            <p class="cr1fot">Weight:
                                                                <a href="#"> 10kg</a>
                                                            </p>
                                                            <div class="prce142">$10</div>
                                                            <button class="shrt-cart-btn" title="cart">
                                                                <i class="uil uil-shopping-cart-alt"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="item">
                                                <div class="fcrse_1 mb-20">
                                                    <div class="fcrse_content">
                                                        <div class="eps_dots more_dropdown">
                                                            <a href="#">
                                                                <i class='uil uil-ellipsis-v'></i>
                                                            </a>
                                                            <div class="dropdown-content">
                                                                <span>
                                                                    <i class='uil uil-share-alt'></i>View</span>
                                                                <span>
                                                                    <i class="uil uil-heart"></i>Change Status</span>
                                                                <span>
                                                                    <i class='uil uil-ban'></i>Edit</span>
                                                                <span>
                                                                    <i class="uil uil-windsock"></i>Spam</span>
                                                            </div>
                                                        </div>
                                                        <div class="vdtodt">
                                                            <span class="vdt14">Booking Date: 10/Aug/2022</span>
                                                        </div>
                                                        <a href="javascript:;" class="crse14s">Consignee Name : James Albert</a>
                                                        <a href="#" class="crse-cate">From: Alaska | To: Chicago</a>
                                                        <div class="auth1lnkprce">
                                                            <p class="cr1fot">Weight:
                                                                <a href="#"> 10kg</a>
                                                            </p>
                                                            <div class="prce142">$10</div>
                                                            <button class="shrt-cart-btn" title="cart">
                                                                <i class="uil uil-shopping-cart-alt"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="item">
                                                <div class="fcrse_1 mb-20">
                                                    <div class="fcrse_content">
                                                        <div class="eps_dots more_dropdown">
                                                            <a href="#">
                                                                <i class='uil uil-ellipsis-v'></i>
                                                            </a>
                                                            <div class="dropdown-content">
                                                                <span>
                                                                    <i class='uil uil-share-alt'></i>View</span>
                                                                <span>
                                                                    <i class="uil uil-heart"></i>Change Status</span>
                                                                <span>
                                                                    <i class='uil uil-ban'></i>Edit</span>
                                                                <span>
                                                                    <i class="uil uil-windsock"></i>Spam</span>
                                                            </div>
                                                        </div>
                                                        <div class="vdtodt">
                                                            <span class="vdt14">Booking Date: 10/Aug/2022</span>
                                                        </div>
                                                        <a href="javascript:;" class="crse14s">Consignee Name : James Albert</a>
                                                        <a href="#" class="crse-cate">From: Alaska | To: Chicago</a>
                                                        <div class="auth1lnkprce">
                                                            <p class="cr1fot">Weight:
                                                                <a href="#"> 10kg</a>
                                                            </p>
                                                            <div class="prce142">$10</div>
                                                            <button class="shrt-cart-btn" title="cart">
                                                                <i class="uil uil-shopping-cart-alt"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="item">
                                                <div class="fcrse_1 mb-20">
                                                    <div class="fcrse_content">
                                                        <div class="eps_dots more_dropdown">
                                                            <a href="#">
                                                                <i class='uil uil-ellipsis-v'></i>
                                                            </a>
                                                            <div class="dropdown-content">
                                                                <span>
                                                                    <i class='uil uil-share-alt'></i>View</span>
                                                                <span>
                                                                    <i class="uil uil-heart"></i>Change Status</span>
                                                                <span>
                                                                    <i class='uil uil-ban'></i>Edit</span>
                                                                <span>
                                                                    <i class="uil uil-windsock"></i>Spam</span>
                                                            </div>
                                                        </div>
                                                        <div class="vdtodt">
                                                            <span class="vdt14">Booking Date: 10/Aug/2022</span>
                                                        </div>
                                                        <a href="javascript:;" class="crse14s">Consignee Name : James Albert</a>
                                                        <a href="#" class="crse-cate">From: Alaska | To: Chicago</a>
                                                        <div class="auth1lnkprce">
                                                            <p class="cr1fot">Weight:
                                                                <a href="#"> 10kg</a>
                                                            </p>
                                                            <div class="prce142">$10</div>
                                                            <button class="shrt-cart-btn" title="cart">
                                                                <i class="uil uil-shopping-cart-alt"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="item">
                                                <div class="fcrse_1 mb-20">
                                                    <div class="fcrse_content">
                                                        <div class="eps_dots more_dropdown">
                                                            <a href="#">
                                                                <i class='uil uil-ellipsis-v'></i>
                                                            </a>
                                                            <div class="dropdown-content">
                                                                <span>
                                                                    <i class='uil uil-share-alt'></i>View</span>
                                                                <span>
                                                                    <i class="uil uil-heart"></i>Change Status</span>
                                                                <span>
                                                                    <i class='uil uil-ban'></i>Edit</span>
                                                                <span>
                                                                    <i class="uil uil-windsock"></i>Spam</span>
                                                            </div>
                                                        </div>
                                                        <div class="vdtodt">
                                                            <span class="vdt14">Booking Date: 10/Aug/2022</span>
                                                        </div>
                                                        <a href="javascript:;" class="crse14s">Consignee Name : James Albert</a>
                                                        <a href="#" class="crse-cate">From: Alaska | To: Chicago</a>
                                                        <div class="auth1lnkprce">
                                                            <p class="cr1fot">Weight:
                                                                <a href="#"> 10kg</a>
                                                            </p>
                                                            <div class="prce142">$10</div>
                                                            <button class="shrt-cart-btn" title="cart">
                                                                <i class="uil uil-shopping-cart-alt"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="item">
                                                <div class="fcrse_1 mb-20">
                                                    <div class="fcrse_content">
                                                        <div class="eps_dots more_dropdown">
                                                            <a href="#">
                                                                <i class='uil uil-ellipsis-v'></i>
                                                            </a>
                                                            <div class="dropdown-content">
                                                                <span>
                                                                    <i class='uil uil-share-alt'></i>View</span>
                                                                <span>
                                                                    <i class="uil uil-heart"></i>Change Status</span>
                                                                <span>
                                                                    <i class='uil uil-ban'></i>Edit</span>
                                                                <span>
                                                                    <i class="uil uil-windsock"></i>Spam</span>
                                                            </div>
                                                        </div>
                                                        <div class="vdtodt">
                                                            <span class="vdt14">Booking Date: 10/Aug/2022</span>
                                                        </div>
                                                        <a href="javascript:;" class="crse14s">Consignee Name : James Albert</a>
                                                        <a href="#" class="crse-cate">From: Alaska | To: Chicago</a>
                                                        <div class="auth1lnkprce">
                                                            <p class="cr1fot">Weight:
                                                                <a href="#"> 10kg</a>
                                                            </p>
                                                            <div class="prce142">$10</div>
                                                            <button class="shrt-cart-btn" title="cart">
                                                                <i class="uil uil-shopping-cart-alt"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="item">
                                                <div class="fcrse_1 mb-20">
                                                    <div class="fcrse_content">
                                                        <div class="eps_dots more_dropdown">
                                                            <a href="#">
                                                                <i class='uil uil-ellipsis-v'></i>
                                                            </a>
                                                            <div class="dropdown-content">
                                                                <span>
                                                                    <i class='uil uil-share-alt'></i>View</span>
                                                                <span>
                                                                    <i class="uil uil-heart"></i>Change Status</span>
                                                                <span>
                                                                    <i class='uil uil-ban'></i>Edit</span>
                                                                <span>
                                                                    <i class="uil uil-windsock"></i>Spam</span>
                                                            </div>
                                                        </div>
                                                        <div class="vdtodt">
                                                            <span class="vdt14">Booking Date: 10/Aug/2022</span>
                                                        </div>
                                                        <a href="javascript:;" class="crse14s">Consignee Name : James Albert</a>
                                                        <a href="#" class="crse-cate">From: Alaska | To: Chicago</a>
                                                        <div class="auth1lnkprce">
                                                            <p class="cr1fot">Weight:
                                                                <a href="#"> 10kg</a>
                                                            </p>
                                                            <div class="prce142">$10</div>
                                                            <button class="shrt-cart-btn" title="cart">
                                                                <i class="uil uil-shopping-cart-alt"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="item">
                                                <div class="fcrse_1 mb-20">
                                                    <div class="fcrse_content">
                                                        <div class="eps_dots more_dropdown">
                                                            <a href="#">
                                                                <i class='uil uil-ellipsis-v'></i>
                                                            </a>
                                                            <div class="dropdown-content">
                                                                <span>
                                                                    <i class='uil uil-share-alt'></i>View</span>
                                                                <span>
                                                                    <i class="uil uil-heart"></i>Change Status</span>
                                                                <span>
                                                                    <i class='uil uil-ban'></i>Edit</span>
                                                                <span>
                                                                    <i class="uil uil-windsock"></i>Spam</span>
                                                            </div>
                                                        </div>
                                                        <div class="vdtodt">
                                                            <span class="vdt14">Booking Date: 10/Aug/2022</span>
                                                        </div>
                                                        <a href="javascript:;" class="crse14s">Consignee Name : James Albert</a>
                                                        <a href="#" class="crse-cate">From: Alaska | To: Chicago</a>
                                                        <div class="auth1lnkprce">
                                                            <p class="cr1fot">Weight:
                                                                <a href="#"> 10kg</a>
                                                            </p>
                                                            <div class="prce142">$10</div>
                                                            <button class="shrt-cart-btn" title="cart">
                                                                <i class="uil uil-shopping-cart-alt"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="item">
                                                <div class="fcrse_1 mb-20">
                                                    <div class="fcrse_content">
                                                        <div class="eps_dots more_dropdown">
                                                            <a href="#">
                                                                <i class='uil uil-ellipsis-v'></i>
                                                            </a>
                                                            <div class="dropdown-content">
                                                                <span>
                                                                    <i class='uil uil-share-alt'></i>View</span>
                                                                <span>
                                                                    <i class="uil uil-heart"></i>Change Status</span>
                                                                <span>
                                                                    <i class='uil uil-ban'></i>Edit</span>
                                                                <span>
                                                                    <i class="uil uil-windsock"></i>Spam</span>
                                                            </div>
                                                        </div>
                                                        <div class="vdtodt">
                                                            <span class="vdt14">Booking Date: 10/Aug/2022</span>
                                                        </div>
                                                        <a href="javascript:;" class="crse14s">Consignee Name : James Albert</a>
                                                        <a href="#" class="crse-cate">From: Alaska | To: Chicago</a>
                                                        <div class="auth1lnkprce">
                                                            <p class="cr1fot">Weight:
                                                                <a href="#"> 10kg</a>
                                                            </p>
                                                            <div class="prce142">$10</div>
                                                            <button class="shrt-cart-btn" title="cart">
                                                                <i class="uil uil-shopping-cart-alt"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <div class="section3126">
                                    <div class="row">
                                        <div class="col-xl-6 col-lg-12 col-md-6">
                                            <div class="value_props">
                                                <div class="value_icon">
                                                    <i class='uil uil-history'></i>
                                                </div>
                                                <div class="value_content">
                                                    <h4>Orders</h4>
                                                    <p>6000+</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-lg-12 col-md-6">
                                            <div class="value_props">
                                                <div class="value_icon">
                                                    <i class='uil uil-user-check'></i>
                                                </div>
                                                <div class="value_content">
                                                    <h4>Customers</h4>
                                                    <p>1500+</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-lg-12 col-md-6">
                                            <div class="value_props">
                                                <div class="value_icon">
                                                    <i class='uil uil-play-circle'></i>
                                                </div>
                                                <div class="value_content">
                                                    <h4>Parcels</h4>
                                                    <p>50000+</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-lg-12 col-md-6">
                                            <div class="value_props">
                                                <div class="value_icon">
                                                    <i class='uil uil-presentation-play'></i>
                                                </div>
                                                <div class="value_content">
                                                    <h4>Sales</h4>
                                                    <p>$ 10200.00</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4">
                                <div class="right_side">
                                    <div class="fcrse_2 mb-30">
                                        <div class="tutor_img">
                                            <a href="javascript:;"><img src="images/left-imgs/img-10.jpg" alt=""></a>
                                        </div>
                                        <div class="tutor_content_dt">
                                            <div class="tutor150">
                                                <a href="javascript:;" class="tutor_name">john doe</a>
                                                <div class="mef78" title="Verify">
                                                    <i class="uil uil-check-circle"></i>
                                                </div>
                                            </div>
                                            <div class="tutor_cate">Web Developer, Designer, and Teacher</div>
                                            <a href="javascript:;" class="prfle12link">Go To Profile</a>
                                        </div>
                                    </div>

                                    <div class="get1452">
                                        <h4>Get personalized recommendations</h4>
                                        <p>Answer a few questions for your top picks</p>
                                        <button class="Get_btn" onclick="window.location.href = '#';">Get Started</button>
                                    </div>

                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <?php include('inc/footer.php'); ?>
            </div>
            <?php include('inc/scripts.php'); ?>
        </body>
    </html>