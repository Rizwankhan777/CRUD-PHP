<footer class="footer mt-30">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="footer_bottm">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <ul class="fotb_left">
                                                <li>
                                                    <p>© 2022
                                                        <strong>NAL</strong>. All Rights Reserved.</p>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="edu_social_links">
                                                <a href="#">
                                                    <i class="fab fa-facebook-f"></i>
                                                </a>
                                                <a href="#">
                                                    <i class="fab fa-twitter"></i>
                                                </a>
                                                <a href="#">
                                                    <i class="fab fa-google-plus-g"></i>
                                                </a>
                                                <a href="#">
                                                    <i class="fab fa-linkedin-in"></i>
                                                </a>
                                                <a href="#">
                                                    <i class="fab fa-instagram"></i>
                                                </a>
                                                <a href="#">
                                                    <i class="fab fa-youtube"></i>
                                                </a>
                                                <a href="#">
                                                    <i class="fab fa-pinterest-p"></i>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </footer>