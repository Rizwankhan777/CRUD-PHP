<header class="header clearfix">
                <button type="button" id="toggleMenu" class="toggle_menu">
                    <i class='uil uil-bars'></i>
                </button>
                <button id="collapse_menu" class="collapse_menu">
                    <i class="uil uil-bars collapse_menu--icon "></i>
                    <span class="collapse_menu--label"></span>
                </button>
                <div class="main_logo" id="logo">
                    <a href="index.php"><img src="images/logo2.png" alt=""></a>
                    <a href="index.php"><img class="logo-inverse" src="images/ct_logo2.png" alt=""></a>
                </div>

                <div class="header_right">
                    <ul>
                        <li>
                            <a href="javascript:;" class="upload_btn" title="Create New Course">Create New Order</a>
                        </li>
                        <li class="ui dropdown">
                            <a href="#" class="option_links" title="Messages">
                                <i class='uil uil-envelope-alt'></i>
                                <span class="noti_count">3</span></a>
                            <div class="menu dropdown_ms">
                                <a href="#" class="channel_my item">
                                    <div class="profile_link">
                                        <img src="images/left-imgs/img-6.jpg" alt="">
                                        <div class="pd_content">
                                            <h6>Zoena Singh</h6>
                                            <p>Booked a new parcel for California</p>
                                            <span class="nm_time">2 min ago</span>
                                        </div>
                                    </div>
                                </a>
                                <a href="#" class="channel_my item">
                                    <div class="profile_link">
                                        <img src="images/left-imgs/img-5.jpg" alt="">
                                        <div class="pd_content">
                                            <h6>Joy Dua</h6>
                                            <p>Booked a new parcel for California</p>
                                            <span class="nm_time">10 min ago</span>
                                        </div>
                                    </div>
                                </a>
                                <a href="#" class="channel_my item">
                                    <div class="profile_link">
                                        <img src="images/left-imgs/img-8.jpg" alt="">
                                        <div class="pd_content">
                                            <h6>Jass</h6>
                                            <p>Booked a new parcel for California</p>
                                            <span class="nm_time">25 min ago</span>
                                        </div>
                                    </div>
                                </a>
                                <a class="vbm_btn" href="javascript:;">View All
                                    <i class='uil uil-arrow-right'></i>
                                </a>
                            </div>
                        </li>
                        <li class="ui dropdown">
                            <a href="#" class="option_links" title="Notifications">
                                <i class='uil uil-bell'></i>
                                <span class="noti_count">3</span></a>
                            <div class="menu dropdown_mn">
                                <a href="#" class="channel_my item">
                                    <div class="profile_link">
                                        <img src="images/left-imgs/img-1.jpg" alt="">
                                        <div class="pd_content">
                                            <h6>Rock William</h6>
                                            <p>Booked a new parcel for California</p>
                                            <span class="nm_time">2 min ago</span>
                                        </div>
                                    </div>
                                </a>
                                <a href="#" class="channel_my item">
                                    <div class="profile_link">
                                        <img src="images/left-imgs/img-2.jpg" alt="">
                                        <div class="pd_content">
                                            <h6>Jassica Smith</h6>
                                            <p>Booked a new parcel for California</p>
                                            <span class="nm_time">12 min ago</span>
                                        </div>
                                    </div>
                                </a>
                                <a href="#" class="channel_my item">
                                    <div class="profile_link">
                                        <img src="images/left-imgs/img-9.jpg" alt="">
                                        <div class="pd_content">
                                            <p>Booked a new parcel for California</p>
                                            <span class="nm_time">20 min ago</span>
                                        </div>
                                    </div>
                                </a>
                                <a class="vbm_btn" href="javascript:;">View All
                                    <i class='uil uil-arrow-right'></i>
                                </a>
                            </div>
                        </li>
                        <li class="ui dropdown">
                            <a href="#" class="opts_account" title="Account">
                                <img src="images/hd_dp.jpg" alt="">
                            </a>
                            <div class="menu dropdown_account">
                                <div class="channel_my">
                                    <div class="profile_link">
                                        <img src="images/hd_dp.jpg" alt="">
                                        <div class="pd_content">
                                            <div class="rhte85">
                                                <h6>john doe</h6>
                                                <div class="mef78" title="Verify">
                                                    <i class='uil uil-check-circle'></i>
                                                </div>
                                            </div>
                                            <span>
                                                <a
                                                    href="https://gambolthemes.net/cdn-cgi/l/email-protection"
                                                    class="__cf_email__"
                                                    data-cfemail="aec9cfc3ccc1c2979a9deec9c3cfc7c280cdc1c3">[email&#160;protected]</a>
                                            </span>
                                        </div>
                                    </div>
                                    <a href="javascript:;" class="dp_link_12">View Instructor Profile</a>
                                </div>
                                <div class="night_mode_switch__btn">
                                    <a href="#" id="night-mode" class="btn-night-mode">
                                        <i class="uil uil-moon"></i>
                                        Night mode
                                        <span class="btn-night-mode-switch">
                                            <span class="uk-switch-button"></span>
                                        </span>
                                    </a>
                                </div>
                                <a href="javascript:;" class="item channel_item">NAL dashboard</a>
                                <a href="javascript:;" class="item channel_item">Paid Memberships</a>
                                <a href="javascript:;" class="item channel_item">Setting</a>
                                <a href="javascript:;" class="item channel_item">Help</a>
                                <a href="javascript:;" class="item channel_item">Send Feedback</a>
                                <a href="javascript:;" class="item channel_item">Sign Out</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </header>