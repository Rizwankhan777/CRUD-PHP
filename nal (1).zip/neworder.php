<!DOCTYPE html>
<html lang="en">
    <head>
        <title>NAL - Index</title>
        <?php include('inc/styles.php'); ?>
        <body>

        <?php include('inc/header.php'); ?> 
        <?php include('inc/nav.php'); ?> 

            <div class="wrapper">
                <div class="sa4d25">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="section3126">
                                <div class="row">
                                        <div class="col-xl-3 col-lg-12 col-md-3">
                                            <div class="value_props">
                                                <div class="value_icon">
                                                    <i class='uil uil-history'></i>
                                                </div>
                                                <div class="value_content">
                                                    <h4>Orders</h4>
                                                    <p>6000+</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-3 col-lg-12 col-md-3">
                                            <div class="value_props">
                                                <div class="value_icon">
                                                    <i class='uil uil-user-check'></i>
                                                </div>
                                                <div class="value_content">
                                                    <h4>Customers</h4>
                                                    <p>1500+</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-3 col-lg-12 col-md-3">
                                            <div class="value_props">
                                                <div class="value_icon">
                                                    <i class='uil uil-play-circle'></i>
                                                </div>
                                                <div class="value_content">
                                                    <h4>Parcels</h4>
                                                    <p>50000+</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-3 col-lg-12 col-md-3">
                                            <div class="value_props">
                                                <div class="value_icon">
                                                    <i class='uil uil-presentation-play'></i>
                                                </div>
                                                <div class="value_content">
                                                    <h4>Sales</h4>
                                                    <p>$ 10200.00</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            </div>
                        </div>
                    </div>
                    <br>
                    <br>
                    <div class="container-fluid">
                        <h1>Add New Order</h1>
                        
                        <form>
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="firstName">First Name:</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="firstName" placeholder="First Name" required>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="lastName">Last Name:</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="lastName" placeholder="Last Name" required>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="emailAddress">Email Address:</label>
                                <div class="col-sm-10">
                                    <input type="email" class="form-control" id="emailAddress" placeholder="Email Address" required>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="phoneNumber">Mobile Number:</label>
                                <div class="col-sm-10">
                                    <input type="number" class="form-control" id="phoneNumber" placeholder="Phone Number" required>
                                </div>
                            </div>        
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label">Date of Birth:</label>
                                <div class="col-sm-3">
                                    <select class="form-control" required>
                                        <option>Date</option>
                                        <option value="1">01</option>
                                        <option value="02">02</option>
                                        <option value="03">03</option>
                                        <option value="04">04</option>
                                        <option value="05">05</option>
                                        <option value="06">06</option>
                                        <option value="07">07</option>
                                        <option value="08">08</option>
                                        <option value="09">09</option>
                                        <option value="10">10</option>
                                        <option value="11">11</option>
                                        <option value="12">12</option>
                                        <option value="13">13</option>
                                        <option value="14">14</option>
                                        <option value="15">15</option>
                                        <option value="16">16</option>
                                        <option value="17">17</option>
                                        <option value="18">18</option>
                                        <option value="19">19</option>
                                        <option value="20">20</option>
                                        <option value="21">21</option>
                                        <option value="22">22</option>
                                        <option value="23">23</option>
                                        <option value="24">24</option>
                                        <option value="25">25</option>
                                        <option value="26">26</option>
                                        <option value="27">27</option>
                                        <option value="28">28</option>
                                        <option value="29">29</option>
                                        <option value="30">30</option>
                                    </select>
                                </div>
                                <div class="col-sm-3">
                                    <select class="form-control" required>
                                        <option>Month</option>
                                        <option value="January">January</option>
                                        <option value="Feburary">Feburary</option>
                                        <option value="March">March</option>
                                        <option value="April">April</option>
                                        <option value="May">May</option>
                                        <option value="June">June</option>
                                        <option value="July">July</option>
                                        <option value="August">August</option>
                                        <option value="September">September</option>
                                        <option value="October">October</option>
                                        <option value="November">November</option>
                                        <option value="December">December</option>
                                    </select>
                                </div>
                                <div class="col-sm-4">
                                    <select class="form-control">
                                        <option>Year</option>
                                        <option value="2022">2022</option>
                                        <option value="2023">2023</option>
                                        <option value="2024">2024</option>
                                        <option value="2025">2025</option>
                                        <option value="2026">2026</option>
                                        <option value="2027">2027</option>
                                        <option value="2028">2028</option>
                                        <option value="2029">2029</option>
                                        <option value="2030">2030</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="postalAddress">Postal Address:</label>
                                <div class="col-sm-10">
                                    <textarea rows="3" class="form-control" id="postalAddress" placeholder="Postal Address" required></textarea>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label class="col-sm-2 col-form-label" for="ZipCode">Zip Code:</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="ZipCode" placeholder="Zip Code" required>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-sm-12 offset-sm-2">
                                    <input type="submit" class="btn btn-primary" value="Submit">
                                    <input type="reset" class="btn btn-secondary ms-2" value="Reset">
                                </div>
                            </div>
                        </form>
                        
                    </div>
                    
                    
                </div>
                <?php include('inc/footer.php'); ?>
            </div>
            <?php include('inc/scripts.php'); ?>
            <script>
                $(document).ready(function () { $('#example').DataTable(); });
            </script>
        </body>
    </html>