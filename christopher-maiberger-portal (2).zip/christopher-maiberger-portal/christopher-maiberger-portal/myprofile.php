<!DOCTYPE html>
<!-- ========================================================= * transport -
Bootstrap 5 HTML Admin Template - Pro | v1.0.0
============================================================== * Product Page:
https://themeselection.com/products/transport-bootstrap-html-admin-template/ *
Created by: ThemeSelection * License: You must have a valid license purchased in
order to legally use the theme for your project. * Copyright ThemeSelection
(https://themeselection.com)
========================================================= -->
<!-- beautify ignore:start -->
<html lang="en" class="light-style layout-menu-fixed" dir="ltr" data-theme="theme-default">

<head>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />
	<title>Dashboard - Customers</title>
	<?php include 'inc/styles.php' ?>
		<!-- Helpers -->
</head>

<body>
	<!-- Layout wrapper -->
	<div class="layout-wrapper layout-content-navbar">
		<div class="layout-container">
        <!-- Menu -->
        <?php include 'inc/nav.php' ?>
        <!-- / Menu -->
        <!-- Layout container -->
        <div class="layout-page">
        <!-- Navbar -->
        <?php include 'inc/header.php' ?>
            <!-- / Navbar -->
            <!-- Content wrapper -->
            <div class="content-wrapper">
                <!-- Content -->
                <div class="container-xxl flex-grow-1 container-p-y">
                    <div class="container bootstrap snippet">
                        <form action="sinc/image_upload.php" method="POST" enctype="multipart/form-data">
                            <div class="col-xs-12"> <img src="http://ssl.gstatic.com/accounts/ui/avatar_2x.png" class="avatar img-circle img-thumbnail" alt="avatar">
                                <h6>Upload a different photo...</h6>
                                <input type="file" class="text-center center-block file-upload" name="file">
                                <input type="submit" />
                            </div>
                            <div class="row">
                                <div class="col-sm-3">
                                    <!--left col-->
                                    </hr>
                                    <br> </div>
                                <!--/col-3-->
                                <div class="col-sm-9">
                                    <div class="tab-content">
                                        <div class="tab-pane active" id="home">
                                            <hr>
                                            <form class="form" action="sinc/myprofile.php" method="post" id="registrationForm">
                                                <div class="form-group">
                                                    <div class="col-xs-6">
                                                        <label for="first_name">
                                                            <h6>First name</h6></label>
                                                        <input type="text" class="form-control" name="first_name" id="first_name" placeholder="first name" title="enter your first name if any."> </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="col-xs-6">
                                                        <label for="last_name">
                                                            <h6>Last name</h6></label>
                                                        <input type="text" class="form-control" name="last_name" id="last_name" placeholder="last name" title="enter your last name if any."> </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="col-xs-6">
                                                        <label for="phone">
                                                            <h6>Phone</h6></label>
                                                        <input type="text" class="form-control" name="phone" id="phone" placeholder="enter phone" title="enter your phone number if any."> </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="col-xs-6 mb-5">
                                                        <label for="mobile">
                                                            <h6>Address</h6></label>
                                                        <input type="text" class="form-control" name="address" id="address" placeholder="Address" title="enter your mobile number if any."> </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="col-xs-12">
                                                        <br>
                                                        <button class="btn btn-lg btn-success" type="submit"><i class="glyphicon glyphicon-ok-sign"></i> Save</button>
                                                        <button class="btn btn-lg" type="reset"><i class="glyphicon glyphicon-repeat"></i> Reset</button>
                                                    </div>
                                                </div>
                                            </form>
                                            <hr> </div>
                                        <!--/tab-pane-->
                                        <div class="tab-pane" id="messages">
                                            <h2></h2>
                                            <hr>
                                            <form class="form" action="##" method="post" id="registrationForm">
                                                <div class="form-group">
                                                    <div class="col-xs-6">
                                                        <label for="first_name">
                                                            <h4>First name</h4></label>
                                                        <input type="text" class="form-control" name="first_name" id="first_name" placeholder="first name" title="enter your first name if any."> </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="col-xs-6">
                                                        <label for="last_name">
                                                            <h4>Last name</h4></label>
                                                        <input type="text" class="form-control" name="last_name" id="last_name" placeholder="last name" title="enter your last name if any."> </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="col-xs-6">
                                                        <label for="phone">
                                                            <h4>Phone</h4></label>
                                                        <input type="text" class="form-control" name="phone" id="phone" placeholder="enter phone" title="enter your phone number if any."> </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="col-xs-6">
                                                        <label for="mobile">
                                                            <h4>Mobile</h4></label>
                                                        <input type="text" class="form-control" name="mobile" id="mobile" placeholder="enter mobile number" title="enter your mobile number if any."> </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="col-xs-6">
                                                        <label for="email">
                                                            <h4>Email</h4></label>
                                                        <input type="email" class="form-control" name="email" id="email" placeholder="you@email.com" title="enter your email."> </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="col-xs-6">
                                                        <label for="email">
                                                            <h4>Location</h4></label>
                                                        <input type="email" class="form-control" id="location" placeholder="somewhere" title="enter a location"> </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="col-xs-6">
                                                        <label for="password">
                                                            <h4>Password</h4></label>
                                                        <input type="password" class="form-control" name="password" id="password" placeholder="password" title="enter your password."> </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="col-xs-6">
                                                        <label for="password2">
                                                            <h4>Verify</h4></label>
                                                        <input type="password" class="form-control" name="password2" id="password2" placeholder="password2" title="enter your password2."> </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="col-xs-12">
                                                        <br>
                                                        <button class="btn btn-lg btn-success" type="submit"><i class="glyphicon glyphicon-ok-sign"></i> Save</button>
                                                        <button class="btn btn-lg" type="reset"><i class="glyphicon glyphicon-repeat"></i> Reset</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                        <!--/tab-pane-->
                                        <div class="tab-pane" id="settings">
                                            <hr>
                                            <form class="form" action="##" method="post" id="registrationForm">
                                                <div class="form-group">
                                                    <div class="col-xs-6">
                                                        <label for="first_name">
                                                            <h4>First name</h4></label>
                                                        <input type="text" class="form-control" name="first_name" id="first_name" placeholder="first name" title="enter your first name if any."> </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="col-xs-6">
                                                        <label for="last_name">
                                                            <h4>Last name</h4></label>
                                                        <input type="text" class="form-control" name="last_name" id="last_name" placeholder="last name" title="enter your last name if any."> </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="col-xs-6">
                                                        <label for="phone">
                                                            <h4>Phone</h4></label>
                                                        <input type="text" class="form-control" name="phone" id="phone" placeholder="enter phone" title="enter your phone number if any."> </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="col-xs-6">
                                                        <label for="mobile">
                                                            <h4>Mobile</h4></label>
                                                        <input type="text" class="form-control" name="mobile" id="mobile" placeholder="enter mobile number" title="enter your mobile number if any."> </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="col-xs-6">
                                                        <label for="email">
                                                            <h4>Email</h4></label>
                                                        <input type="email" class="form-control" name="email" id="email" placeholder="you@email.com" title="enter your email."> </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="col-xs-6">
                                                        <label for="email">
                                                            <h4>Location</h4></label>
                                                        <input type="email" class="form-control" id="location" placeholder="somewhere" title="enter a location"> </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="col-xs-6">
                                                        <label for="password">
                                                            <h4>Password</h4></label>
                                                        <input type="password" class="form-control" name="password" id="password" placeholder="password" title="enter your password."> </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="col-xs-6">
                                                        <label for="password2">
                                                            <h4>Verify</h4></label>
                                                        <input type="password" class="form-control" name="password2" id="password2" placeholder="password2" title="enter your password2."> </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="col-xs-12">
                                                        <br>
                                                        <button class="btn btn-lg btn-success pull-right" type="submit"><i class="glyphicon glyphicon-ok-sign"></i> Save</button>
                                                        <!--<button class="btn btn-lg" type="reset"><i class="glyphicon glyphicon-repeat"></i> Reset</button>-->
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                    <!--/tab-pane-->
                                </div>
                                <!--/tab-content-->
                            </div>
                            <!--/col-9-->
                    </div>
                    <!--/row-->
                </div>
                <!-- / Content -->
                <?php include 'inc/footer.php' ?>
                <!-- / Layout wrapper -->
                <?php include 'inc/scripts.php' ?>
            </div>
        </div>
    </div>
</body>

</html>