

<!DOCTYPE html>

<!-- =========================================================
* transport - Bootstrap 5 HTML Admin Template - Pro | v1.0.0
==============================================================

* Product Page: https://themeselection.com/products/transport-bootstrap-html-admin-template/
* Created by: ThemeSelection
* License: You must have a valid license purchased in order to legally use the theme for your project.
* Copyright ThemeSelection (https://themeselection.com)

=========================================================
 -->
<!-- beautify ignore:start -->
<html
  lang="en"
  class="light-style layout-menu-fixed"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="assets/"
  data-template="vertical-menu-template-free"
>
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />

    <title>Dashboard - Analytics |</title>
   <?php include 'inc/styles.php' ?>

    <!-- Helpers -->
  
  </head>

  <body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
        <!-- Menu -->
<?php include 'inc/nav.php' ?>
        <!-- / Menu -->
        <!-- Layout container -->
        <div class="layout-page">
          <!-- Navbar -->
<?php include 'inc/header.php' ?>

          <!-- / Navbar -->

          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">
              <div class="row">
              <div class="col-10 mx-auto">
                <h1>Apply For Position</h1>
            <p>
                    <!-- <a class="btn btn-primary" data-bs-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
                    Experience
                    </a> -->
                    <!-- <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
                        Experience
                    </button> -->
                    </p>
                    <!-- <div class="collapse" id="collapseExample"> -->
                    <div class="card card-body">
                    <div class="page-content">
                <div class="row">
                <form action="sinc/apply_for_position_config.php" method="POST">
                <input type="hidden" name="_token" value="jBiwSQU01zz1iQoY3lj5pNeoKYnKkx3lZV7N5jeu">                    
                <div class="col-md-12">
                    <br>
                        <h4 class="frm_section_n">Experience:</h4>
                            <div class="form_field_outer">
                                <div class="form_field_outer_row">
                                    <button type="button" class="btn btn-primary" data-bs-toggle="collapse" data-bs-target="#demo" style="float: right;" aria-expanded="true">+</button>            
                                    <br>
                                    <div id="demo" class="collapse show" style="">
                                        <div class="mb-3">
                                            <label class="form-label">Company:</label>
                                            <input type="company" required="" name="company[]" id="company" class="form-control">
                                            <!-- <input type="experience" class="form-control"> -->
                                        </div>
                                        <div class="mb-3">
                                        <br>
                                            <label class="form-label">Experience:</label>
                                            <textarea type="experience" required="" name="experience[]" id="experience" class="form-control"></textarea>
                                            <!-- <input type="experience" class="form-control"> -->
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Designation:</label>
                                            <input type="designation" required="" name="designation[]" id="designation" class="form-control">
                                        </div>
                                        <div class="row">
                                            <div class="col-sm-6 mb-3">
                                                <label class="form-label">Start Date:</label>
                                                <input type="date" required="" name="start_date[]" id="start_date" class="form-control datepicker3">
                                            </div>
                                            <div class="col-sm-6 mb-3">
                                                    <label class="form-label">End Date:</label>
                                                    <input type="date" required="" name="end_date[]" id="end_date" class="form-control datepicker4">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                    <br>
                </div>
                            <div class="row ml-0 bg-light mt-3 border py-3">
                                <div class="col-md-12">
                                    <button class="btn btn-outline-lite py-0 add_new_frm_field_btn" type="button"><i class="fas fa-plus" style="margin-top: -12px;"></i> Add Experience</button>
                                </div>
                            </div>
                    </div>
                    <!-- <div class="mb-3">
                            <br>
                            <label class="form-label">Resume:</label>
                            <input type="file" required="" name="resume" class="form-control">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Certificate:</label>
                            <input type="file" name="certificate" class="form-control">
                        </div> -->
                        <div class="col float-end">
                            <button type="submit" class="btn btn-primary px-5 radius-30 text-left">Submit</button>
                        </div>
                        
                </form></div>
                        
                    </div>
                    </div>
                    <!-- </div> -->
            </div>


                
                    </div>
                  </div>
                </div>
                <!--/ Transactions -->
              </div>
            </div>
</div>
            <!-- / Content -->

<?php include 'inc/footer.php' ?>
    <!-- / Layout wrapper -->

   
<?php include'inc/scripts.php' ?>
  </body>
</html>
