<!DOCTYPE html>
<!-- =========================================================
* transport - Bootstrap 5 HTML Admin Template - Pro | v1.0.0
==============================================================
* Product Page: https://themeselection.com/products/transport-bootstrap-html-admin-template/
* Created by: ThemeSelection
* License: You must have a valid license purchased in order to legally use the theme for your project.
* Copyright ThemeSelection (https://themeselection.com)
=========================================================
 -->
<!-- beautify ignore:start -->
<html
  lang="en"
  class="light-style layout-menu-fixed"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="assets/"
  data-template="vertical-menu-template-free"
>
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />

    <title>Request Page|</title>
   <?php include 'inc/styles.php' ?>

    <!-- Helpers -->
  
  </head>

  <body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
        <!-- Menu -->
<?php include 'inc/nav.php' ?>
        <!-- / Menu -->
        <!-- Layout container -->
        <div class="layout-page">
          <!-- Navbar -->
<?php include 'inc/header.php' ?>

          <!-- / Navbar -->

          <!-- Content wrapper -->
          <div class="content-wrapper ">
            <!-- Content -->
            <div class="container ">
        <div class="row">
            <div class="column mx-10 mb-3">
            <form action="sinc/request_config.php" method="POST">
                      <div class="mb-5">
                        <label for="exampleInputEmail1" class="form-label">From Address</label>
                        <input type="text" class="form-control" id="exampleInputText1" aria-describedby="textHelp" name="from_address" required>
                      </div>
                    <div class="row">
                    <div class="col-6 mb-3">
                        <label for="exampleInputEmail1" class="form-label">State</label>
                        <input type="text" class="form-control" id="exampleInputText1" aria-describedby="textHelp" name="from_state" required>
                      </div>
                      <div class="col-6 mb-3">
                        <label for="exampleInputEmail1" class="form-label">City</label>
                        <input type="text" class="form-control" id="exampleInputText1" aria-describedby="textHelp" name="from_city" required>
                      </div>
                    </div>
                      <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Country</label>
                        <input type="text" class="form-control" id="exampleInputText1" aria-describedby="textHelp" name="from_country" required>
                      </div>
                      <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Zip Code</label>
                        <input type="text" class="form-control" id="exampleInputText1" aria-describedby="textHelp" name="from_zipcode" required>
                      </div>
                      <h3 class="text-center">  To</h3>
                      <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">To Address</label>
                        <input type="text" class="form-control" id="exampleInputText1" aria-describedby="textHelp" name="to_address" required>
                      </div>
                      <div class="row">
                      <div class="col-6 mb-3">
                        <label for="exampleInputEmail1" class="form-label">State</label>
                        <input type="text" class="form-control" id="exampleInputText1" aria-describedby="textHelp" name="to_state" required>
                      </div>
                      <div class="col-6 mb-3">
                        <label for="exampleInputEmail1" class="form-label">City</label>
                        <input type="text" class="form-control" id="exampleInputText1" aria-describedby="textHelp" name="to_city" required>
                      </div>
                      </div>
                      <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Country</label>
                        <input type="text" class="form-control" id="exampleInputText1" aria-describedby="textHelp" name="to_country" required>
                      </div>
                      <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Zip Code</label>
                        <input type="text" class="form-control" id="exampleInputText1" aria-describedby="textHelp" name="to_zipcode" required> 
                      </div>
                      
                      <div class="mb-3">
                      <label for="cars">Choose Truck</label>
                      <select name="truck" id="truck">
                      <option value="truckload">Truck Load</option>
                      <option value="halftruckload">Half Truck Load</option>
                      <option value="etc">ETC</option>
                    </select>
                    </div>
                <div class="col-md-12 text-center">
                <button type="submit" class="btn btn-primary text-center">Request</button>
              </button>
        </form>
            </div>
        </div>
    </div>
</div>
            <!-- / Content -->

<?php include 'inc/footer.php' ?>
    <!-- / Layout wrapper -->

   
<?php include'inc/scripts.php' ?>
  </body>
</html>
