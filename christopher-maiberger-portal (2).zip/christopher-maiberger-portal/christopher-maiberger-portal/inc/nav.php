
        <aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
          <div class="app-brand demo">
            <a href="javascript:;" class="app-brand-link">
              <span class="app-brand-logo demo">
             <div>
              <img src="assets/img/logo.png" class="img-fluid" alt="">
             </div>
                  <g id="g-app-brand" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                    <g id="Brand-Logo" transform="translate(-27.000000, -15.000000)">
                      <g id="Icon" transform="translate(27.000000, 15.000000)">
                        <g id="Mask" transform="translate(0.000000, 8.000000)">
                          <mask id="mask-2" fill="white">
                            <use xlink:href="#path-1"></use>
                          </mask>
                          <use fill="#E74C3C" xlink:href="#path-1"></use>
                          <g id="Path-3" mask="url(#mask-2)">
                            <use fill="#E74C3C" xlink:href="#path-3"></use>
                            <use fill-opacity="0.2" fill="#FFFFFF" xlink:href="#path-3"></use>
                          </g>
                          <g id="Path-4" mask="url(#mask-2)">
                            <use fill="#E74C3C" xlink:href="#path-4"></use>
                            <use fill-opacity="0.2" fill="#FFFFFF" xlink:href="#path-4"></use>
                          </g>
                        </g>
                        <g
                          id="Triangle"
                          transform="translate(19.000000, 11.000000) rotate(-300.000000) translate(-19.000000, -11.000000) "
                        >
                          <use fill="#E74C3C" xlink:href="#path-5"></use>
                          <use fill-opacity="0.2" fill="#FFFFFF" xlink:href="#path-5"></use>
                        </g>
                      </g>
                    </g>
                  </g>
                </svg>
              </span>
              <!-- <span class="app-brand-text demo menu-text fw-bolder ms-2">transport</span> -->
            </a>

            <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
              <i class="bx bx-chevron-left bx-sm align-middle"></i>
            </a>
          </div>

          <div class="menu-inner-shadow"></div>
            <?php
            $current_page = basename($_SERVER['PHP_SELF'], ".php"); 
            ?>
          <ul class="menu-inner py-1">
            <!-- Dashboard -->
            <li class="menu-item <?php if($current_page=="index"){ echo 'active'; } ?>">
              <a href="index.php" class="menu-link">
                <i class="menu-icon tf-icons bx bx-home-circle"></i>
                <div data-i18n="Analytics">Home</div>
              </a>
            </li>

            <li class="menu-item <?php if($current_page=="allcustomers"){ echo 'active'; } ?>">
              <a href="allcustomers.php" class="menu-link">
                <i class="uil uil-user menu--icon"></i>
                <i class="menu-icon tf-icons bx bx-user-circle"></i>
                <div data-i18n="Analytics">Customers</div>
              </a>
            </li>
            <li class="menu-item <?php if($current_page=="add-orders" || $current_page=="allorder"){ echo 'active'; } ?>">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-layout"></i>
                <!-- <i class="fa-solid fa-bring-forward"></i> -->
                <div data-i18n="Layouts">Orders</div>
              </a>

              <ul class="menu-sub">
                <li class="menu-item">
                  <a href="add-orders.php" class="menu-link">
                    <div data-i18n="Without menu">Add Order</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="allorder.php" class="menu-link">
                    <div data-i18n="Without navbar">All Orders</div>
                  </a>
                </li>
           
              </ul>
            </li>



            <li class="menu-item <?php if($current_page=="shipments"){ echo 'active'; } ?>">
              <a href="shipments.php" class="menu-link">
                <!-- <i class="fa-solid fa-box-open"></i> -->
                <!-- <i class="menu-icon tf-icons bx bx-box-circle"></i> -->
                <i class="fa-solid fa-box-open tf-icons menu-icon"></i>
                <div data-i18n="Analytics">Shipments</div>
              </a>
            </li>


            <li class="menu-item <?php if($current_page=="sales"){ echo 'active'; } ?>">
              <a href="sales.php" class="menu-link">
                <!-- <i class="menu-icon tf-icons bx bx-sales-circle"></i> -->
                <i class="fa-solid fa-list menu-icon "></i>
                <div data-i18n="Analytics">Sales</div>
              </a>
            </li>

            <li class="menu-item <?php if($current_page=="myprofile"){ echo 'active'; } ?>">
              <a href="myprofile.php" class="menu-link">
                <!-- <i class="menu-icon tf-icons bx bx-setting-circle"></i> -->
                <i class="fa-sharp fa-solid fa-gear menu-icon"></i>
                <div data-i18n="Analytics">My Profile</div>
              </a>
            </li>
           <?php
             if($user_role=="customer")
            {?>
            <li class='menu-item <?php if($current_page="request"){ echo 'active'; } ?>'>
              <a href='request.php' class='menu-link'>
               <!-- <i class='menu-icon tf-icons bx bx-setting-circle'></i> -->
               <i class='menu-icon tf-icons bx bx-user-circle'></i>
               <div data-i18n='Analytics'>Request</div>
             </a>
           </li>
           <li class='menu-item <?php if($current_page=="apply_for_position"){ echo 'active'; } ?>'>
             <a href='apply_for_position.php' class='menu-link'>
               <!-- <i class='menu-icon tf-icons bx bx-setting-circle'></i> -->
               <i class='menu-icon tf-icons bx bx-user-circle'></i>
               <div data-i18n='Analytics'>Apply For Position</div>
             </a>
           </li>
           <?php
             }
             ?>
           <?php
             if($user_role=="admin")
            {?>
             <li class='menu-item <?php if($current_page=='all_request'){ echo 'active'; } ?>'>
             <a href='all_request.php' class='menu-link'>
               <!-- <i class='menu-icon tf-icons bx bx-setting-circle'></i> -->
               <i class='menu-icon tf-icons bx bx-user-circle'></i>
               <div data-i18n='Analytics'>Request</div>
             </a>
           </li>
           <li class='menu-item <?php if($current_page=='position_request'){ echo 'active'; } ?>'>
             <a href='position_request.php' class='menu-link'>
               <!-- <i class='menu-icon tf-icons bx bx-setting-circle'></i> -->
               <i class='menu-icon tf-icons bx bx-user-circle'></i>
               <div data-i18n='Analytics'>Postion Requests</div>
             </a>
           </li>
            <?php
            }
            ?>
     

          </ul>
        </aside>


        