<?php
        include('config.php');
        session_start();
        $id= ($_POST['id']);
        $from_address= ($_POST['from_address']);
        $from_state= $_POST['from_state'];
        $from_city= ($_POST['from_city']);
        $from_country=($_POST['from_country']);
        $from_zipcode=($_POST['from_zipcode']);
        $to_address= ($_POST['to_address']);
        $to_state= $_POST['to_state'];
        $to_city= ($_POST['to_city']);
        $to_country=($_POST['to_country']);
        $to_zipcode=($_POST['to_zipcode']);
        $truck=($_POST['truck']);
        $check=mysqli_query($conn,"UPDATE `request_page` SET `from_address`='$from_address',`from_state`='$from_state',`from_city`='$from_city',`from_country`='$from_country',`from_zipcode`='$from_zipcode', `to_address`='$to_address',`to_state`='$to_state',`to_city`='$to_city',`to_country`='$to_country',`to_zipcode`='$to_zipcode' where id='$id';");
         if($check){
         header("location:/christopher-maiberger-portal/christopher-maiberger-portal/shipments.php");
         }
        else{
            echo"failed";
        }
        ?>