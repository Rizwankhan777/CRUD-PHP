<?php
        include('config.php');
        $check=mysqli_query($conn,"SELECT * FROM `request_page`;");
        $num = mysqli_num_rows($check);
        if ($num >0){
                        while($row = mysqli_fetch_assoc($check))
                        {
                        echo"
                        <tbody class='table-border-bottom-0'>
                        <tr>
                        <tbody>
                        <tr>
                          <td>".$row['shippment_id']."</td>
                          <td>".$row['from_address']."</td>
                          <td>".$row['to_address']."</td>
                          <td>".$row['from_country']."</td>
                          <td>".$row['to_country']."</td>
                        </tr>
                      </tbody>
                        </tr>
                        </tbody>
                        ";
                        }
}
?>     

