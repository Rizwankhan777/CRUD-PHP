<?php   
session_start();
session_destroy();
header("location:/christopher-maiberger-portal/christopher-maiberger-portal/login.php");
exit();
?>