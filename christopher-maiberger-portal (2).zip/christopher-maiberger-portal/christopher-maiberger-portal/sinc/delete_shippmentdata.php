<?php
        include('config.php');
        session_start();
        $id=$_POST['id'];
        $check=mysqli_query($conn,"DELETE FROM `request_page` WHERE id='$id';");
         if($check){
         header("location:/christopher-maiberger-portal/christopher-maiberger-portal/shipments.php");
         }
        else{
        }
        ?>