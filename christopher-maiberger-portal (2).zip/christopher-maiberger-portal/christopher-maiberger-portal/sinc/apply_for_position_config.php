<?php
include('config.php');
include('../inc/styles.php');
$id="APC".rand(10,100).time();
$company= json_encode($_POST['company']);
$experience= json_encode($_POST['experience']);
$designation= json_encode($_POST['designation']);
$start_date=json_encode($_POST['start_date']);
$end_date=json_encode($_POST['end_date']);
 $check=mysqli_query($conn,"INSERT INTO `apply_for_position` (`id`, `user_id`, `appointment_key`, `company`, `experience`, `designation`, `start_date`, `end_date`) 
 VALUES ('','$user_id','$id', '$company', '$experience', '$designation', '$start_date', '$end_date');");
 if($check){ 
       header("location:/christopher-maiberger-portal/christopher-maiberger-portal/apply_for_position.php");;
 }
 else{
        echo"failed";
 }