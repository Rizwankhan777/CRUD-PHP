<?php
        include('config.php');
        $check=mysqli_query($conn,"SELECT users.fname,users.lname,users.address,users.contact_no,users.state FROM `users` LEFT JOIN `apply_for_position` ON users.user_id = apply_for_position.user_id;");
        $num = mysqli_num_rows($check);
        if ($num >0){
                        while($row = mysqli_fetch_assoc($check))
                        {
                        echo"
                        <tbody class='table-border-bottom-0'>
                        <tr>
                        <tbody>
                        <tr>
                          <td>".($row['fname'])." ".($row['lname'])."</td>
                          <td>".($row['address'])."</td>
                          <td>".($row['contact_no'])."</td>
                          <td>".($row['state'])."</td>
                        </tr>
                      </tbody>
                        </tr>
                        </tbody>
                        ";
                        }
}
?>     

