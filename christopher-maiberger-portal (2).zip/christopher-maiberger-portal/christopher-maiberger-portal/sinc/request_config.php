<script>
    var myModal = document.getElementById('myModal')
var myInput = document.getElementById('myInput')

myModal.addEventListener('shown.bs.modal', function () {
  myInput.focus()
})
    </script>
<?php

include('config.php');
include('../inc/styles.php');
$shippment_id="SHIPKEY".rand(10,100).time();
$from_address= ($_POST['from_address']);
$from_state= $_POST['from_state'];
$from_city= ($_POST['from_city']);
$from_country=($_POST['from_country']);
$from_zipcode=($_POST['from_zipcode']);
$to_address= ($_POST['to_address']);
$to_state= $_POST['to_state'];
$to_city= ($_POST['to_city']);
$to_country=($_POST['to_country']);
$to_zipcode=($_POST['to_zipcode']);
$truck=($_POST['truck']);
$check=mysqli_query($conn,"INSERT INTO `request_page` (`id`, `shippment_id`, `from_address`, `from_state`, `from_city`, `from_country`, `from_zipcode`, `to_address`, `to_state`, `to_city`, `to_country`, `to_zipcode`, `truck`) VALUES ('', '$shippment_id', '$from_address', '$from_state', '$from_city', '$from_country', '$from_zipcode', '$to_address', '$to_state', '$to_city', '$to_country', '$to_zipcode', '$truck');");

if($check){
  
echo "<script>alert('Your request has been submitted')</script>";
header("location:/christopher-maiberger-portal/christopher-maiberger-portal/index.php");
}
else{
 echo"<script>alert('Failed')</script>";
 header("location:/christopher-maiberger-portal/christopher-maiberger-portal/request.php");
}

mysqli_close($conn);



?>

