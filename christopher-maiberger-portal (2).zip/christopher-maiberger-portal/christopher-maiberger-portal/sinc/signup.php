<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Signup</title>
  </head>
<?php

include('config.php');
$userid="USRKY".rand(10,100).time();
$fname = $_POST['fname'];
$lname= ($_POST['lname']);
$user_role= ($_POST['user_role']);
$address = $_POST['address'];
$state = ($_POST['state']);
$contact_no= ($_POST['contact_no']);
$email = $_POST['email'];
$password = ($_POST['password']);
// var_dump($_POST);die;
$check=mysqli_query($conn,"SELECT * FROM `users` WHERE `email`='$email';");
// print_r($check);
// $num = mysqli_num_rows($check);
// echo $num;
if ($check->num_rows==0){
	//$row = mysqli_fetch_assoc($check);
  // if($row){
    $check1=mysqli_query($conn,"INSERT INTO `users` (`user_id`,`fname`,`lname`, `user_role`, `address`, `state`, `contact_no`, `email`, `password`) VALUES ('$userid','$fname','$lname',  '$user_role', '$address', '$state', '$contact_no', '$email ', '$password');");
    if($check1){
  
      echo " <div class='alert alert-primary' role='alert'>
      Registered sucessfully </br><p>Your user ID IS $userid </P>
      </div>";
      }
      else{
       echo"<div class='alert alert-danger' role='alert'>
       Failed
      </div>";
      }
      
//   }
}
else{
  echo "Email Already exists";
}
//


mysqli_close($conn);



?>