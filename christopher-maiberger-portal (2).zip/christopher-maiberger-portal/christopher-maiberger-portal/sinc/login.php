<?php
include('config.php');
// var_dump($_POST);die;

$email = $_POST['email'];
$password = ($_POST['password']);
$check=mysqli_query($conn,"SELECT * FROM `users` WHERE `email`='$email' and `password`='$password';");
$num = mysqli_num_rows($check);
if ($num >0){
	session_start(); 
	$row = mysqli_fetch_assoc($check);
	$fname=$_SESSION['fname'] = $row['fname'];
	$user_role=$_SESSION['user_role'] = $row['user_role'];
	$user_id=$_SESSION['user_id'] = $row['user_id'];
  echo"login sucess";
}
else{
  echo"User does not exists";
}
mysqli_close($conn);

?>