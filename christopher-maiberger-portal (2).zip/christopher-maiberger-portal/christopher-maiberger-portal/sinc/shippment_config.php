<?php

include('config.php');
//$password = ($_POST['password']);
$check=mysqli_query($conn,"SELECT * FROM `request_page`;");
$num = mysqli_num_rows($check);
if ($num >0){
	session_start(); 
	$row = mysqli_fetch_assoc($check);
	$shippment_id=$_SESSION['shippment_id'] = $row['shippment_id'];
	$from_address=$_SESSION['from_address'] = $row['from_address'];
    $to_address=$_SESSION['to_address'] = $row['to_address'];
	$truck=$_SESSION['truck'] = $row['truck'];
	echo $shippment_id;
	echo $from_address;
	echo $to_address;
	echo $truck;
}
else{
  echo"User does not exists";
}
mysqli_close($conn);

?>