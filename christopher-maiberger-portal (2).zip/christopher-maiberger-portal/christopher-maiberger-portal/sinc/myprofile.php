<?php
include('config.php');
include('../inc/styles.php');
$first_name = $_POST['first_name'];
$last_name= ($_POST['last_name']);
$phone= $_POST['phone'];
$address=($_POST['address']);
$check=mysqli_query($conn,"UPDATE`users`SET`fname`='$first_name',`lname`='$last_name' ,`address`='$address',`contact_no`='$phone' WHERE `user_id`='$user_id';");
if($check){
    $_SESSION['fname'] = $first_name;
echo " <div class='alert alert-primary' role='alert'>
<p>Sucessfully updated</P>
</div>";
}
else{
 echo"<div class='alert alert-danger' role='alert'>
 Failed
</div>";
}
mysqli_close($conn);
?>
