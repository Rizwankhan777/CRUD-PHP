<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "christopher";

global $conn;
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
/* Check connection
if ($conn) {
    echo"Connection sucessfull";
}
else{
    echo"Connection failed";
}
*/
 ?>
