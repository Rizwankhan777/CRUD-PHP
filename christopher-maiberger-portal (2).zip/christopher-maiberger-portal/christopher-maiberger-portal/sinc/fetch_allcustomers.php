<?php
        include('config.php');
        $check=mysqli_query($conn,"SELECT * FROM `users` WHERE user_role='customer';");
        $num = mysqli_num_rows($check);
        if ($num >0){
                        while($row = mysqli_fetch_assoc($check))
                        {
                        echo"
                        <tbody class='table-border-bottom-0'>
                        <tr>
                          <td> <strong>".$row['user_id']."</strong></td>
                          <td>".$row['fname']."</td>
                          <td>".$row['address']."</td>
                          <td>".$row['contact_no']."</td>
                          <td><span class='badge bg-label-success me-1'>".$row['state']."</span></td>
                        </tr>
                        </tbody>
                        ";
                        }
}
?>     