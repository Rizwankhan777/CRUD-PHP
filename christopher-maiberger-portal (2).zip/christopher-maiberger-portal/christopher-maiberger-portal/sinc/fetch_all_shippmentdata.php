<?php
        include('config.php');
        $check=mysqli_query($conn,"SELECT * FROM `request_page`  ;");
        $num = mysqli_num_rows($check);
        if ($num >0){
                        while($row = mysqli_fetch_assoc($check))
                        {
                   
                        echo"
                        <tbody class='table-border-bottom-0'>
                        <tr>
                        <td> <strong>".$row['shippment_id']."</strong></td>
                        <td>".$row['from_address']."</td>
                        <td>".$row['to_address']."</td>
                        <td>".$row['truck']."</td>
                        <td class='d-flex justify-content-around' style='width:200px'>
                        <form action='sinc/delete_shippmentdata.php' method='post'>
                        <input type='hidden' name='id' value=".$row['id'].">
                         <input type='submit' name='delete' class='btn btn-danger'>
                         </form>
                         <!-- Button trigger modal -->
                                    <button type='button' class='btn btn-primary' data-bs-toggle='modal' data-bs-target='#exampleModal'>
                                    Update
                                    </button>
                                    <!-- Modal -->
                                    <div class='modal fade' id='exampleModal' tabindex='-1' aria-labelledby='exampleModalLabel' aria-hidden='true'>
                                    <div class='modal-dialog'>
                                        <div class='modal-content'>
                                        <div class='modal-header'>
                                            <h5 class='modal-title' id='exampleModalLabel'>Update Address</h5>
                                            <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
                                        </div>
                                        <form action='sinc/update_shippmentdata.php' method='post'>
                                        <div class='modal-body'>
                                        <div class='mb-3'>
                                                <label for='exampleInputEmail1' class='form-label'>From Address</label>
                                                <input type='text' class='form-control' id='exampleInputText1' aria-describedby='textHelp' name='from_address' required>
                                            </div>
                                            <div class='row'>
                                            <div class='col-6 mb-3'>
                                                <label for='exampleInputEmail1' class='form-label'>State</label>
                                                <input type='='text' class='form-control' id='exampleInputText1' aria-describedby='textHelp' name='from_state' required>
                                            </div>
                                            <div class='col-6 mb-3'>
                                                <label for='exampleInputEmail1' class='form-label'>City</label>
                                                <input type='text' class='form-control' id='exampleInputText1' aria-describedby='textHelp' name='from_city' required>
                                            </div>
                                            </div>
                                            <div class='mb-3'>
                                                <label for='exampleInputEmail1' class='form-label'>Country</label>
                                                <input type='text' class='form-control' id='exampleInputText1' aria-describedby='textHelp' name='from_country' required>
                                            </div>
                                            <div class='mb-3'>
                                                <label for='exampleInputEmail1' class='form-label'>Zip Code</label>
                                                <input type='text' class='form-control' id='exampleInputText1' aria-describedby='textHelp' name='from_zipcode' required>
                                            </div>
                                            <h3 class='text-center'>  To</h3>
                                            <div class='mb-3'>
                                                <label for='exampleInputEmail1' class='form-label'>To Address</label>
                                                <input type='text' class='form-control' id='exampleInputText1' aria-describedby='textHelp' name='to_address' required>
                                            </div>
                                            <div class='row'>
                                            <div class='col-6 mb-3'>
                                                <label for='exampleInputEmail1' class='form-label'>State</label>
                                                <input type='text' class='form-control' id='exampleInputText1' aria-describedby='textHelp' name='to_state' required>
                                            </div>
                                            <div class='col-6 mb-3'>
                                                <label for='exampleInputEmail1' class='form-label'>City</label>
                                                <input type='text' class='form-control' id='exampleInputText1' aria-describedby='textHelp' name='to_city' required>
                                            </div>
                                            </div>
                                            <div class='mb-3'>
                                                <label for='exampleInputEmail1' class='form-label'>Country</label>
                                                <input type='text' class='form-control' id='exampleInputText1' aria-describedby='textHelp' name='to_country' required>
                                            </div>
                                            <div class='mb-3'>
                                                <label for='exampleInputEmail1' class='form-label'>Zip Code</label>
                                                <input type='text' class='form-control' id='exampleInputText1' aria-describedby='textHelp' name='to_zipcode' required> 
                                            </div>
                                            
                                            <div class='mb-3'>
                                            <label for='cars'>Choose Truck</label>
                                            <select name='truck' id='truck'>
                                            <option value='truckload'>Truck Load</option>
                                            <option value='halftruckload'>Half Truck Load</option>
                                            <option value='etc'>ETC</option>
                                            </select>
                                            </div>
                                      <div class='modal-footer'>
                                        </div>
                                        <input type='hidden' name='id' value=".$row['id'].">
                                        <input type='submit' name='delete' class='btn btn-danger'>
                                        </form>
                                            <button type='button' class='btn btn-secondary' data-bs-dismiss='modal'>Close</button>  
                                        </div>
                                        </div>
                                    </div>
                                    </div>
                         </td>

                        
                    </tbody>
                        ";
                        }
} 
?>     
