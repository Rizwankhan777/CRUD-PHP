

<!DOCTYPE html>

<!-- =========================================================
* transport - Bootstrap 5 HTML Admin Template - Pro | v1.0.0
==============================================================

* Product Page: https://themeselection.com/products/transport-bootstrap-html-admin-template/
* Created by: ThemeSelection
* License: You must have a valid license purchased in order to legally use the theme for your project.
* Copyright ThemeSelection (https://themeselection.com)

=========================================================
 -->
<!-- beautify ignore:start -->
<html
  lang="en"
  class="light-style layout-menu-fixed"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="assets/"
  data-template="vertical-menu-template-free"
>
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />

    <title>Dashboard - Employee</title>
   <?php include 'inc/styles.php' ?>

    <!-- Helpers -->
  
  </head>

  <body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
        <!-- Menu -->
<?php include 'inc/nav.php' ?>
        <!-- / Menu -->
        <!-- Layout container -->
        <div class="layout-page">
          <!-- Navbar -->
<?php include 'inc/header.php' ?>

          <!-- / Navbar -->

          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">
              <div class="row">



                <div class="col-lg-6 mb-4 order-0">
                  <div class="row">
                    <div class="col-6 mb-4">
                      <div class="card">
                        <div class="card-body">
                          <div class="card-title d-flex align-items-start justify-content-between">
                            <div class="avatar flex-shrink-0">
                              <img src="assets/img/icons/unicons/paypal.png" alt="Credit Card" class="rounded" />
                            </div>
                            <div class="dropdown">
                              <button
                                class="btn p-0"
                                type="button"
                                id="cardOpt4"
                                data-bs-toggle="dropdown"
                                aria-haspopup="true"
                                aria-expanded="false"
                              >
                                <i class="bx bx-dots-vertical-rounded"></i>
                              </button>
                              <div class="dropdown-menu dropdown-menu-end" aria-labelledby="cardOpt4">
                                <a class="dropdown-item" href="javascript:void(0);">View More</a>
                                <a class="dropdown-item" href="javascript:void(0);">Delete</a>
                              </div>
                            </div>
                          </div>
                          <span class="d-block mb-1">Orders</span>
                          <h3 class="card-title text-nowrap mb-2">6000+</h3>
                          <small class="text-danger fw-semibold"><i class="bx bx-down-arrow-alt"></i> -14.82%</small>
                        </div>
                      </div>
                    </div>


                    <div class="col-6 mb-4">
                      <div class="card">
                        <div class="card-body">
                          <div class="card-title d-flex align-items-start justify-content-between">
                            <div class="avatar flex-shrink-0">
                              <img src="assets/img/icons/unicons/cc-primary.png" alt="Credit Card" class="rounded" />
                            </div>
                            <div class="dropdown">
                              <button
                                class="btn p-0"
                                type="button"
                                id="cardOpt1"
                                data-bs-toggle="dropdown"
                                aria-haspopup="true"
                                aria-expanded="false"
                              >
                                <i class="bx bx-dots-vertical-rounded"></i>
                              </button>
                              <div class="dropdown-menu" aria-labelledby="cardOpt1">
                                <a class="dropdown-item" href="javascript:void(0);">View More</a>
                                <a class="dropdown-item" href="javascript:void(0);">Delete</a>
                              </div>
                            </div>
                          </div>
                          <span class="fw-semibold d-block mb-1">Customers</span>
                          <h3 class="card-title mb-2">1,857</h3>
                          <small class="text-success fw-semibold"><i class="bx bx-up-arrow-alt"></i> +28.14%</small>
                        </div>
                      </div>
                    </div>

                  </div>

                </div>
                <div class="col-lg-6 col-md-4 order-1">
                  <div class="row">
                    <div class="col-lg-6 col-md-12 col-6 mb-4">
                      <div class="card">
                        <div class="card-body">
                          <div class="card-title d-flex align-items-start justify-content-between">
                            <div class="avatar flex-shrink-0">
                              <img
                                src="assets/img/icons/unicons/chart-success.png"
                                alt="chart success"
                                class="rounded"
                              />
                            </div>
                            <div class="dropdown">
                              <button
                                class="btn p-0"
                                type="button"
                                id="cardOpt3"
                                data-bs-toggle="dropdown"
                                aria-haspopup="true"
                                aria-expanded="false"
                              >
                                <i class="bx bx-dots-vertical-rounded"></i>
                              </button>
                              <div class="dropdown-menu dropdown-menu-end" aria-labelledby="cardOpt3">
                                <a class="dropdown-item" href="javascript:void(0);">View More</a>
                                <a class="dropdown-item" href="javascript:void(0);">Delete</a>
                              </div>
                            </div>
                          </div>
                          <span class="fw-semibold d-block mb-1">Parcels</span>
                          <h3 class="card-title mb-2">12,628</h3>
                          <small class="text-success fw-semibold"><i class="bx bx-up-arrow-alt"></i> +72.80%</small>
                        </div>
                      </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-6 mb-4">
                      <div class="card">
                        <div class="card-body">
                          <div class="card-title d-flex align-items-start justify-content-between">
                            <div class="avatar flex-shrink-0">
                              <img
                                src="assets/img/icons/unicons/wallet-info.png"
                                alt="Credit Card"
                                class="rounded"
                              />
                            </div>
                            <div class="dropdown">
                              <button
                                class="btn p-0"
                                type="button"
                                id="cardOpt6"
                                data-bs-toggle="dropdown"
                                aria-haspopup="true"
                                aria-expanded="false"
                              >
                                <i class="bx bx-dots-vertical-rounded"></i>
                              </button>
                              <div class="dropdown-menu dropdown-menu-end" aria-labelledby="cardOpt6">
                                <a class="dropdown-item" href="javascript:void(0);">View More</a>
                                <a class="dropdown-item" href="javascript:void(0);">Delete</a>
                              </div>
                            </div>
                          </div>
                          <span>Sales</span>
                          <h3 class="card-title text-nowrap mb-1">$4,679</h3>
                          <small class="text-success fw-semibold"><i class="bx bx-up-arrow-alt"></i> +28.42%</small>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- Total Revenue -->
              </div>
              
              <div class="">
                
                <div class="card">
                  <h5 class="card-header">New Employee</h5>
                  
                  <div class="container">
                      <form class="addneworderform">
                        <div class="row">
                          <div class="col-md-6">
                            <div class="form-group">
                              <label for="first">First Name</label>
                              <input type="text" class="form-control" placeholder="" id="first">
                            </div>
                          </div>
                          <!--  col-md-6   -->
                    
                          <div class="col-md-6">
                            <div class="form-group">
                              <label for="last">Last Name</label>
                              <input type="text" class="form-control" placeholder="" id="last">
                            </div>
                          </div>
                          <!--  col-md-6   -->
                        </div>
                    
                    
                        <div class="row">
                        <div class="col-md-6">
                    <div class="form-group">
                      <label for="email">Email address</label>
                      <input type="email" class="form-control" id="email" placeholder="email">
                    </div>
                  </div>
                    
                    
                          
                          <!--  col-md-6   -->
                    
                          <div class="col-md-6">
                    
                            <div class="form-group">
                              <label for="phone">Phone Number</label>
                              <input type="tel" class="form-control" id="phone" placeholder="phone">
                            </div>
                          </div>
                          <!--  col-md-6   -->
                        </div>
                        <!--  row   -->
                    
                    
                        <div class="row">
                       
                          <!--  col-md-6   -->
                    
                          <div class="col-md-6">
                            <div class="form-group">
                              <label for="url">Upload CV</small></label>
                              <input type="file" class="form-control" id="url" placeholder="Upload cv">
                            </div>
                    
                          </div>
                          <!--  col-md-6   -->
                        </div>
                        <!--  row   -->
                        <hr>
                        <button type="submit" class=" btn btn-primary">Submit</button>
                      </form>
                    </div>
                  
                </div>
                  
              </div>
              <div class="card my-5 py-3">
             <div class="container">
                <div class="row">
                    <div class="col-md-12">
                    <button type="submit" class="progressbtn btn btn-info">Review Progress</button>
                    <div class="table-responsive text-nowrap progressdiv">
                    <table class="table">
                      <thead>
                        <tr>
                          <th>Employee CV</th>
                          <th>Progress</th>
                          <!-- <th>Accept</th>
                          <th>Reject</th>
                          <th>Actions</th> -->
                        </tr>
                      </thead>
                      <tbody class="table-border-bottom-0">
                        <tr>
                          <td> <strong>File </strong> <small>KSAY3274.pdf</small> </td>
                          <td><span class="badge bg-label-primary me-2">PENDING</span> <span class="badge bg-label-info me-1">REJECT</span> <span class="badge bg-label-danger me-1">ACCEPT</span></td>
                          <!-- <td><span class="badge bg-label-primary me-2">PENDING</span></td>
                          <td><span class="badge bg-label-info me-1">ACCEPT</span></td>
                          <td><span class="badge bg-label-danger me-1">ACCEPT</span></td> -->
                          <td>
                            <div class="dropdown">
                              <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown"><i class="bx bx-dots-vertical-rounded"></i></button>
                              <div class="dropdown-menu">
                                <a class="dropdown-item" href="javascript:void(0);"><i class="bx bx-edit-alt me-1"></i> Edit</a>
                                <a class="dropdown-item" href="javascript:void(0);"><i class="bx bx-trash me-1"></i> Delete</a>
                              </div>
                            </div>
                          </td>
                        </tr>
                
                    
                        
                      </tbody>
                    </table>
                  </div>
                    </div>
                </div>
             </div>

              </div>
              
            </div>
            <!-- / Content -->

<?php include 'inc/footer.php' ?>
    <!-- / Layout wrapper -->

   
<?php include'inc/scripts.php' ?>

<style>
.progressdiv {
display: none;
}
</style>

<script>
$(document).ready(function(){
  $(".progressbtn").click(function(){
    $(".progressdiv").toggle();
  });
});
</script>


  </body>
</html>
