<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Log In</title>
  </head>
  <body>
<div class="container">
    <div class="row">
        <div class="col-md-6 mx-auto">
        <h1 class="text-center">Log In</h1>
    <form id="login_custom">
    <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Email</label>
    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="text" name="email" required>
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Password</label>
    <input type="password" class="form-control" id="exampleInputPassword1" name="password" required>
  </div>
  <input type="submit" class="btn btn-primary" value="Submit">
</form>
        </div>
    </div>
</div>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
<script>
$('#login_custom').submit(function(e){
e.preventDefault();
// var exampleInputEmail1 = $('#exampleInputEmail1').val();
// var exampleInputPassword1 = $('#exampleInputPassword1').val();

 formdata = $("#login_custom").serialize();

  $.ajax({
      url: "sinc/login.php",
      type: "POST",
      data: formdata,
      success: function (data) {
      
        if(data=='login sucess'){
          window.location.href="index.php";
        }
        else{
          window.alert("Wrong username or password");
        }
      }
    });

});
</script>
  </body>
</html>