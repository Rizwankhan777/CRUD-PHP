<!DOCTYPE html>
<!-- =========================================================
* transport - Bootstrap 5 HTML Admin Template - Pro | v1.0.0
==============================================================
* Product Page: https://themeselection.com/products/transport-bootstrap-html-admin-template/
* Created by: ThemeSelection
* License: You must have a valid license purchased in order to legally use the theme for your project.
* Copyright ThemeSelection (https://themeselection.com)
=========================================================
 -->
<!-- beautify ignore:start -->
<html
  lang="en"
  class="light-style layout-menu-fixed"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="assets/"
  data-template="vertical-menu-template-free"
>
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />

    <title>Request Page|</title>
   <?php include 'inc/styles.php' ?>

    <!-- Helpers -->
  
  </head>

  <body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
        <!-- Menu -->
<?php include 'inc/nav.php' ?>
        <!-- / Menu -->
        <!-- Layout container -->
        <div class="layout-page">
          <!-- Navbar -->
<?php include 'inc/header.php' ?>

          <!-- / Navbar -->

          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->
            <div class="container-xxl flex-grow-1 container-p-y">
              
            <div class="">
                
                <div class="card">
                  <h5 class="card-header">All REQUESTS</h5>
                  <div class="table-responsive text-nowrap">
                    <table class="table">
                      <thead>
                        <tr>
                          <th>Name</th>
                          <th>Address</th>
                          <th>Contact-No</th>
                          <th>State</th>
                        </tr>
                      </thead>
                      <?php
                    include("sinc/position_request_config.php");
                    ?>
                    </table>
                  </div>
                </div>
                  
              </div>
</body>
      <!--  -->        
            <!-- / Content -->


    <!-- / Layout wrapper -->

   
<?php include'inc/scripts.php' ?>
<?php include 'inc/footer.php' ?>
  </body>
</html>
