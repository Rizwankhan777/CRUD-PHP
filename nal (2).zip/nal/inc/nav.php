<nav class="vertical_nav">
                <div class="left_section menu_left" id="js-menu">
                    <div class="left_section">
                        <ul>
                            <li class="menu--item">
                                <a href="index.php" class="menu--link active" title="Home">
                                    <i class='uil uil-home-alt menu--icon'></i>
                                    <span class="menu--label">Home</span>
                                </a>
                            </li>
                            <li class="menu--item">
                                <a href="allcustomers.php" class="menu--link" title="Explore">
                                    <i class='uil uil-user menu--icon'></i>
                                    <span class="menu--label">Customers</span>
                                </a>
                            </li>
                            <li class="menu--item menu--item__has_sub_menu">
                                <label class="menu--link" title="Categories">
                                    <i class='uil uil-layers menu--icon'></i>
                                    <span class="menu--label">Orders</span>
                                </label>
                                <ul class="sub_menu">
                                    <li class="sub_menu--item">
                                        <a href="neworder.php" class="sub_menu--link">Add Order</a>
                                    </li>
                                    <li class="sub_menu--item">
                                        <a href="allorders.php" class="sub_menu--link">All Orders</a>
                                    </li>
                                </ul>
                            </li>

                            <li class="menu--item">
                                <a href="parcels.php" class="menu--link" title="Saved Courses">
                                    <i class="uil uil-box menu--icon"></i>
                                    <span class="menu--label">Parcels</span>
                                </a>
                            </li>
                            <li class="menu--item">
                                <a href="sales.php" class="menu--link" title="Saved Courses">
                                    <i class='uil uil-file menu--icon'></i>
                                    <span class="menu--label">Sales</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                    
                    <div class="left_section pt-2">
                        <ul>
                            <li class="menu--item">
                                <a href="javascript:;" class="menu--link" title="Setting">
                                    <i class='uil uil-cog menu--icon'></i>
                                    <span class="menu--label">My Profile</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="left_footer">
                        <div class="left_footer_content">
                            <p>© 2022<strong>NAL</strong>. All Rights Reserved.</p>
                        </div>
                    </div>
                </div>
            </nav>