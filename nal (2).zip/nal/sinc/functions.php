<?php include('config.php');
function login_user($emailaddress,$password){
    global $conn;
    $sql=mysqli_query($conn,"SELECT * FROM `user_master` where `email`='$emailaddress' and `password`='$password';");
    $num = mysqli_num_rows($sql);
    if($num)
    {
        return (mysqli_fetch_array($sql));
    }
    
}
function user_register($user_name,$emailaddress,$password){
    global $conn;
    $user_id="USRKY".rand(10,100).time();
    $sql=mysqli_query($conn,"INSERT INTO `user_master` (`user_id`, `user_name`, `email`, `password`) VALUES ('$user_id', '$user_name', '$emailaddress', '$password');");
    if($sql)
    {
        return (mysqli_fetch_array($sql));
    }
   
}
?>