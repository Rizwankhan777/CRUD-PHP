<?php
include('config.php');
include('functions.php');
session_start();

if ($_POST['type'] == 'login') {
    $emailaddress=$_POST['email_address'];
    $password=md5($_POST['password']);
    $data = login_user($emailaddress, $password);
    if($data){ 
        
        $user_id=$_SESSION['user_id'] = $data[1];   
        $user_name=$_SESSION['user_name'] = $data[2];   
        echo(1);
    }
}
if ($_POST['type'] == 'signup') {
    $user_name=$_POST['user_name'];
    $emailaddress=$_POST['email_address'];
    $password=md5($_POST['password']);
    $sql= user_register($user_name,$emailaddress,$password);
    if($sql){
        echo (1);
    }
}
?>
